## EN
Go to secrets, type in the key case `Token` and paste your bot token in value case, easy right? 

## FR

Allez dans les secrets, tapez la casse clé « TOKEN » et collez votre jeton de bot dans la casse des valeurs, facile non ?

## SP

Vaya a los secretos, escriba en el caso clave "TOKEN" y pegue su token de bot en el caso de valor, fácil, ¿verdad?

## RS

Перейдите к секретам, введите ключевой регистр `TOKEN` и вставьте свой токен бота в регистр значения, легко, не так ли?