exports.TOKEN = `MTI2NjU4ODYyMzgzNTM2NTQ5MA.Gt9x6m.u5aDMoQIgmHnyEi9RJ2GYkUt8PRYiV1kKFsyiY`;
exports.Prefix = `.`;
exports.Token = ``;
exports.Color = `#2C2F33`;
exports.Port = `8080`;
exports.BotName= `Moderation Bot`;